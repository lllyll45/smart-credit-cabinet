
import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react'
import {
  NavLink,
  Navigate,
  Route,
  Routes,
  useNavigate,
  useParams,
} from 'react-router-dom'
import { api } from './api/client'
import './App.css'

type User = {
  id: number
  email: string
  created_at: string
}

type CreditProduct = {
  id: number
  name: string
  bank_name: string
  interest_rate: number | string
  min_amount: number | string
  max_amount: number | string
  min_term_months: number
  max_term_months: number
  commission_rate: number | string | null
  commission_amount: number | string | null
  additional_conditions: string | null
  is_active: boolean
}

type Calculation = {
  product_id: number
  product_name: string
  bank_name: string
  interest_rate: number | string
  amount: number | string
  term_months: number
  monthly_payment: number | string
  total_payment: number | string
  overpayment: number | string
  commission: number | string
}

type Application = {
  id: number
  user_id: number
  credit_product_id: number | null
  amount: number | string
  term_months: number
  purpose: string
  monthly_income: number | string
  employment: string
  status: string
  comment: string | null
  decision_comment: string | null
  monthly_payment: number | string | null
  total_payment: number | string | null
  overpayment: number | string | null
  created_at: string
  updated_at: string
}

type AuthProps = {
  user: User | null
  onLogin: (token: string, user: User) => void
  onLogout: () => void
}

const navigation = [
  { to: '/dashboard', label: 'Главная', icon: '⌂' },
  { to: '/credits', label: 'Кредитные предложения', icon: '▤' },
  { to: '/credits/compare', label: 'Сравнение кредитов', icon: '⇄' },
  { to: '/applications', label: 'Мои заявки', icon: '▣' },
]

const TOKEN_KEY = 'smart-credit-access-token'

function formatMoney(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === '') return '—'
  const number = Number(value)
  if (!Number.isFinite(number)) return '—'

  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    maximumFractionDigits: 2,
  }).format(number)
}

function formatDate(value: string): string {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('ru-RU')
}

function getErrorMessage(error: unknown): string {
  if (typeof error === 'object' && error !== null && 'response' in error) {
    const response = (error as {
      response?: { data?: { detail?: unknown } }
    }).response

    const detail = response?.data?.detail
    if (typeof detail === 'string') return detail
    if (Array.isArray(detail)) {
      return detail
        .map((item) =>
          typeof item === 'object' && item !== null && 'msg' in item
            ? String(item.msg)
            : String(item),
        )
        .join('; ')
    }
  }

  if (error instanceof Error) {
    if (error.message === 'Network Error') {
      return 'Не удалось подключиться к серверу. Проверь, что бэкенд запущен.'
    }
    return error.message
  }

  return 'Произошла неизвестная ошибка.'
}



function useLoad<T>(url: string, enabled = true) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(enabled)
  const [error, setError] = useState('')

  const reload = useCallback(async () => {
    if (!enabled) return

    setLoading(true)
    setError('')

    try {
      const response = await api.get<T>(url)
      setData(response.data)
    } catch (err) {
      setError(getErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }, [url, enabled])

  useEffect(() => {
    if (!enabled) return

    let cancelled = false

    async function fetchData() {
      try {
        const response = await api.get<T>(url)
        if (!cancelled) {
          setData(response.data)
        }
      } catch (err) {
        if (!cancelled) {
          setError(getErrorMessage(err))
        }
      } finally {
        if (!cancelled) {
          setLoading(false)
        }
      }
    }

    void fetchData()

    return () => {
      cancelled = true
    }
  }, [url, enabled])

  return { data, loading, error, reload }
}

function LoadingState() {
  return (
    <section className="content-card">
      <p>Загружаем данные…</p>
    </section>
  )
}

function ErrorMessage({ children }: { children: ReactNode }) {
  return (
    <div className="form-error" role="alert">
      {children}
    </div>
  )
}

function StatusMessage({ children }: { children: ReactNode }) {
  return (
    <div className="form-success" role="status">
      {children}
    </div>
  )
}

function Field({
  label,
  children,
}: {
  label: string
  children: ReactNode
}) {
  return (
    <label className="form-field">
      <span>{label}</span>
      {children}
    </label>
  )
}

function Layout({
  user,
  onLogout,
  children,
}: AuthProps & { children: ReactNode }) {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <NavLink to="/dashboard" className="brand">
          <span className="brand-icon">S</span>
          <span>
            <strong>Smart Credit</strong>
            <small>Личный кабинет</small>
          </span>
        </NavLink>

        <div className="nav-caption">МЕНЮ</div>

        <nav className="navigation">
          {navigation.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/dashboard'}
              className={({ isActive }) =>
                `nav-link ${isActive ? 'active' : ''}`
              }
            >
              <span className="nav-icon">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="help-card">
            <span className="help-icon">?</span>
            <strong>Нужна помощь?</strong>
            <p>Сравнивайте условия кредитов и следите за заявками в одном месте.</p>
          </div>
          <span className="version">SMART CREDIT CABINET · MVP</span>
        </div>
      </aside>

      <div className="main-column">
        <header className="topbar">
          <div>
            <span className="topbar-label">ФИНАНСОВЫЙ ПОМОЩНИК</span>
            <h2>Smart Credit Cabinet</h2>
          </div>
          {user ? (
            <div className="account-actions">
              <span className="user-email">{user.email}</span>
              <button className="secondary-button" onClick={onLogout}>
                Выйти
              </button>
            </div>
          ) : (
            <NavLink to="/login" className="login-link">
              <span>↗</span> Войти
            </NavLink>
          )}
        </header>

        <main className="page-content">{children}</main>

        <footer className="footer">
          <span>Smart Credit Cabinet</span>
          <span>Итоговые условия определяются кредитором</span>
        </footer>
      </div>
    </div>
  )
}

function PageHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string
  title: string
  description: string
}) {
  return (
    <div className="page-heading">
      <span className="eyebrow">{eyebrow}</span>
      <h1>{title}</h1>
      <p>{description}</p>
    </div>
  )
}

function DashboardPage({ user }: { user: User | null }) {
  const { data: products, loading, error } = useLoad<CreditProduct[]>('/products')
  const { data: applications } = useLoad<Application[]>(
  '/applications',
  Boolean(user),
)

  return (
    <>
      <PageHeading
        eyebrow="ВАШЕ ФИНАНСОВОЕ ПРОСТРАНСТВО"
        title={user ? `Рады видеть вас, ${user.email.split('@')[0]}!` : 'Добро пожаловать!'}
        description="Подбирайте кредитные предложения, рассчитывайте платежи и следите за заявками."
      />

      <section className="welcome-banner">
        <div className="welcome-copy">
          <span className="banner-tag">SMART CREDIT</span>
          <h2>Найдите кредит на своих условиях</h2>
          <p>
            Сравните доступные предложения и оцените ежемесячный платёж
            до оформления заявки.
          </p>
          <NavLink to="/credits" className="primary-button">
            Смотреть предложения <span>→</span>
          </NavLink>
        </div>
        <div className="banner-decoration" aria-hidden="true">
          <div className="decoration-circle">₽</div>
          <div className="decoration-card">Ваши цели. Ваш выбор.</div>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <h2>Обзор кабинета</h2>
            <p>Основные возможности сервиса</p>
          </div>
        </div>

        <div className="action-grid">
          <NavLink to="/credits" className="action-card">
            <span className="action-icon purple">▤</span>
            <h3>Каталог кредитов</h3>
            <p>
              {loading
                ? 'Загружаем доступные продукты…'
                : error
                  ? 'Не удалось загрузить каталог.'
                  : `Доступно предложений: ${products?.length ?? 0}`}
            </p>
            <span className="card-link">Открыть каталог →</span>
          </NavLink>

          <NavLink to="/credits/compare" className="action-card">
            <span className="action-icon green">⇄</span>
            <h3>Сравнить предложения</h3>
            <p>Сравните платежи, переплату и общую сумму выплат.</p>
            <span className="card-link">Сравнить кредиты →</span>
          </NavLink>

          <NavLink to={user ? '/applications' : '/login'} className="action-card">
            <span className="action-icon orange">▣</span>
            <h3>Мои заявки</h3>
            <p>
              {user
                ? `Заявок в кабинете: ${applications?.length ?? '…'}`
                : 'Войдите, чтобы работать со своими заявками.'}
            </p>
            <span className="card-link">Перейти →</span>
          </NavLink>
        </div>
      </section>

      <div className="notice">
        <span>i</span>
        <p>
          Расчёты носят информационный характер и не являются одобрением
          кредита банком.
        </p>
      </div>
    </>
  )
}

function CreditsPage() {
  const { data: products, loading, error, reload } =
    useLoad<CreditProduct[]>('/products')

  return (
    <>
      <PageHeading
        eyebrow="КАТАЛОГ"
        title="Кредитные предложения"
        description="Данные загружаются из API вашего бэкенда."
      />

      {loading && <LoadingState />}
      {error && (
        <section className="content-card">
          <ErrorMessage>{error}</ErrorMessage>
          <button className="primary-button button-spaced" onClick={() => void reload()}>
            Повторить загрузку
          </button>
        </section>
      )}

      {!loading && !error && products?.length === 0 && (
        <section className="content-card">
          <h2>Пока нет доступных продуктов</h2>
          <p>Попробуйте зайти позже.</p>
        </section>
      )}

      {!loading && !error && products && products.length > 0 && (
        <div className="product-grid">
          {products.map((product) => (
            <article className="content-card product-card" key={product.id}>
              <span className="eyebrow">{product.bank_name}</span>
              <h2>{product.name}</h2>
              <div className="product-rate">
                {Number(product.interest_rate).toLocaleString('ru-RU')}%
                <small> годовых</small>
              </div>
              <div className="details-list">
                <div>
                  <span>Сумма кредита</span>
                  <strong>
                    {formatMoney(product.min_amount)} – {formatMoney(product.max_amount)}
                  </strong>
                </div>
                <div>
                  <span>Срок</span>
                  <strong>
                    {product.min_term_months}–{product.max_term_months} мес.
                  </strong>
                </div>
                <div>
                  <span>Комиссия</span>
                  <strong>
                    {product.commission_rate != null
                      ? `${product.commission_rate}%`
                      : product.commission_amount != null
                        ? formatMoney(product.commission_amount)
                        : 'Не указана'}
                  </strong>
                </div>
              </div>
              {product.additional_conditions && (
                <p className="product-conditions">{product.additional_conditions}</p>
              )}
              <NavLink
                to={`/applications/new?product=${product.id}`}
                className="primary-button full-button"
              >
                Подать заявку <span>→</span>
              </NavLink>
            </article>
          ))}
        </div>
      )}
    </>
  )
}

function ComparePage() {
  const [amount, setAmount] = useState('300000')
  const [term, setTerm] = useState('24')
  const [results, setResults] = useState<Calculation[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [searched, setSearched] = useState(false)

  async function compare(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setLoading(true)
    setSearched(true)

    try {
      const response = await api.post<{
        amount: number | string
        term_months: number
        products: Calculation[]
      }>('/calculator/compare', {
        amount: Number(amount),
        term_months: Number(term),
      })
      setResults(response.data.products)
    } catch (err) {
      setError(getErrorMessage(err))
      setResults([])
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <PageHeading
        eyebrow="КАЛЬКУЛЯТОР"
        title="Сравнение кредитов"
        description="Введите желаемую сумму и срок, чтобы сравнить доступные продукты."
      />

      <section className="content-card">
        <form className="form-grid" onSubmit={compare}>
          <Field label="Сумма кредита, ₽">
            <input
              type="number"
              min="1"
              step="0.01"
              required
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
            />
          </Field>
          <Field label="Срок, месяцев">
            <input
              type="number"
              min="1"
              max="360"
              required
              value={term}
              onChange={(event) => setTerm(event.target.value)}
            />
          </Field>
          <button className="primary-button form-submit" type="submit" disabled={loading}>
            {loading ? 'Рассчитываем…' : 'Сравнить предложения'}
          </button>
        </form>
        {error && <ErrorMessage>{error}</ErrorMessage>}
      </section>

      {searched && !loading && !error && results.length === 0 && (
        <section className="content-card">
          <p>Для указанной суммы и срока подходящих продуктов не найдено.</p>
        </section>
      )}

      {results.length > 0 && (
        <section className="section-block">
          <div className="section-heading">
            <div>
              <h2>Результаты сравнения</h2>
              <p>
                Сумма: {formatMoney(amount)} · Срок: {term} мес.
              </p>
            </div>
          </div>
          <div className="comparison-list">
            {results.map((item, index) => (
              <article className="content-card comparison-card" key={item.product_id}>
                <div className="comparison-title">
                  <span className="rank-badge">{index + 1}</span>
                  <div>
                    <h3>{item.product_name}</h3>
                    <p>{item.bank_name} · ставка {item.interest_rate}%</p>
                  </div>
                </div>
                <div className="comparison-metrics">
                  <div>
                    <span>Ежемесячный платёж</span>
                    <strong>{formatMoney(item.monthly_payment)}</strong>
                  </div>
                  <div>
                    <span>Переплата</span>
                    <strong>{formatMoney(item.overpayment)}</strong>
                  </div>
                  <div>
                    <span>Общая выплата</span>
                    <strong>{formatMoney(item.total_payment)}</strong>
                  </div>
                  <div>
                    <span>Комиссия</span>
                    <strong>{formatMoney(item.commission)}</strong>
                  </div>
                </div>
                <NavLink
                  to={`/applications/new?product=${item.product_id}&amount=${amount}&term=${term}`}
                  className="secondary-button"
                >
                  Подать заявку
                </NavLink>
              </article>
            ))}
          </div>
        </section>
      )}
    </>
  )
}

function LoginPage({ onLogin }: Pick<AuthProps, 'onLogin'>) {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setLoading(true)

    try {
      const form = new URLSearchParams()
      form.set('username', email)
      form.set('password', password)

      const tokenResponse = await api.post<{ access_token: string; token_type: string }>(
        '/auth/login',
        form,
        { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } },
      )

      const token = tokenResponse.data.access_token
      const userResponse = await api.get<User>('/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      })

      onLogin(token, userResponse.data)
      navigate('/dashboard')
    } catch (err) {
      setError(getErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <PageHeading
        eyebrow="ВАШ АККАУНТ"
        title="Вход в кабинет"
        description="Войдите, чтобы управлять своими заявками."
      />
      <section className="content-card auth-card">
        <h2>Авторизация</h2>
        <form className="form-grid single-column" onSubmit={submit}>
          <Field label="Электронная почта">
            <input
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="name@example.com"
            />
          </Field>
          <Field label="Пароль">
            <input
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Ваш пароль"
            />
          </Field>
          {error && <ErrorMessage>{error}</ErrorMessage>}
          <button className="primary-button" type="submit" disabled={loading}>
            {loading ? 'Входим…' : 'Войти'}
          </button>
        </form>
        <p className="auth-switch">
          Нет аккаунта? <NavLink to="/register">Зарегистрироваться</NavLink>
        </p>
      </section>
    </>
  )
}

function RegisterPage({ onLogin }: Pick<AuthProps, 'onLogin'>) {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')

    if (password.length < 8) {
      setError('Пароль должен содержать не менее 8 символов.')
      return
    }

    setLoading(true)

    try {
      await api.post<User>('/auth/register', { email, password })

      const form = new URLSearchParams()
      form.set('username', email)
      form.set('password', password)

      const tokenResponse = await api.post<{ access_token: string; token_type: string }>(
        '/auth/login',
        form,
        { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } },
      )

      const token = tokenResponse.data.access_token
      const userResponse = await api.get<User>('/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      })

      onLogin(token, userResponse.data)
      navigate('/dashboard')
    } catch (err) {
      setError(getErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <PageHeading
        eyebrow="НОВЫЙ АККАУНТ"
        title="Регистрация"
        description="Создайте аккаунт, чтобы работать с кредитными заявками."
      />
      <section className="content-card auth-card">
        <h2>Создание аккаунта</h2>
        <form className="form-grid single-column" onSubmit={submit}>
          <Field label="Электронная почта">
            <input
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="name@example.com"
            />
          </Field>
          <Field label="Пароль (не менее 8 символов)">
            <input
              type="password"
              autoComplete="new-password"
              minLength={8}
              maxLength={128}
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Придумайте пароль"
            />
          </Field>
          {error && <ErrorMessage>{error}</ErrorMessage>}
          <button className="primary-button" type="submit" disabled={loading}>
            {loading ? 'Создаём аккаунт…' : 'Зарегистрироваться'}
          </button>
        </form>
        <p className="auth-switch">
          Уже есть аккаунт? <NavLink to="/login">Войти</NavLink>
        </p>
      </section>
    </>
  )
}

function ApplicationsPage({ user }: { user: User | null }) {
  const navigate = useNavigate()
  const { data, loading, error, reload } = useLoad<Application[]>('/applications')

  if (!user) return <Navigate to="/login" replace />

  return (
    <>
      <PageHeading
        eyebrow="ВАШ КАБИНЕТ"
        title="Мои заявки"
        description="Просматривайте черновики, статусы и результаты рассмотрения."
      />

      <div className="section-heading">
        <div>
          <h2>История заявок</h2>
          <p>Здесь отображаются заявки текущего пользователя.</p>
        </div>
        <button
          className="primary-button"
          onClick={() => navigate('/applications/new')}
        >
          + Новая заявка
        </button>
      </div>

      {loading && <LoadingState />}
      {error && (
        <section className="content-card">
          <ErrorMessage>{error}</ErrorMessage>
          <button className="secondary-button button-spaced" onClick={() => void reload()}>
            Повторить
          </button>
        </section>
      )}

      {!loading && !error && data?.length === 0 && (
        <section className="content-card">
          <h2>Заявок пока нет</h2>
          <p>Создайте заявку, чтобы начать работу.</p>
          <button
            className="primary-button button-spaced"
            onClick={() => navigate('/applications/new')}
          >
            Создать заявку
          </button>
        </section>
      )}

      {!loading && !error && data && data.length > 0 && (
        <div className="application-list">
          {data.map((item) => (
            <NavLink
              to={`/applications/${item.id}`}
              className="content-card application-row"
              key={item.id}
            >
              <div>
                <span className="eyebrow">ЗАЯВКА № {item.id}</span>
                <h3>{item.purpose}</h3>
                <p>
                  {formatMoney(item.amount)} · {item.term_months} мес. ·{' '}
                  {formatDate(item.created_at)}
                </p>
              </div>
              <span className={`status-pill status-${item.status}`}>
                {statusLabel(item.status)}
              </span>
            </NavLink>
          ))}
        </div>
      )}
    </>
  )
}

function statusLabel(status: string): string {
  const labels: Record<string, string> = {
    draft: 'Черновик',
    pending: 'На рассмотрении',
    approved: 'Одобрена',
    rejected: 'Отклонена',
    submitted: 'Отправлена',
  }
  return labels[status] ?? status
}

function NewApplicationPage({ user }: { user: User | null }) {
  const navigate = useNavigate()
  const { data: products, loading: productsLoading, error: productsError } =
    useLoad<CreditProduct[]>('/products')

  const params = new URLSearchParams(window.location.search)
  const initialProduct = params.get('product') ?? ''
  const initialAmount = params.get('amount') ?? ''
  const initialTerm = params.get('term') ?? ''

  const [productId, setProductId] = useState(initialProduct)
  const [amount, setAmount] = useState(initialAmount)
  const [term, setTerm] = useState(initialTerm)
  const [purpose, setPurpose] = useState('')
  const [income, setIncome] = useState('')
  const [employment, setEmployment] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (!user) return <Navigate to="/login" replace />

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setLoading(true)

    try {
      const response = await api.post<Application>('/applications', {
        credit_product_id: Number(productId),
        amount: Number(amount),
        term_months: Number(term),
        purpose: purpose.trim(),
        monthly_income: Number(income),
        employment: employment.trim(),
      })

      navigate(`/applications/${response.data.id}`)
    } catch (err) {
      setError(getErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  const selectedProduct = products?.find((product) => product.id === Number(productId))

  return (
    <>
      <PageHeading
        eyebrow="КРЕДИТНАЯ ЗАЯВКА"
        title="Новая заявка"
        description="Заполните данные. Сначала заявка будет сохранена как черновик."
      />
      <section className="content-card">
        {productsLoading && <p>Загружаем кредитные продукты…</p>}
        {productsError && <ErrorMessage>{productsError}</ErrorMessage>}

        {!productsLoading && !productsError && (
          <form className="form-grid" onSubmit={submit}>
            <Field label="Кредитный продукт">
              <select
                required
                value={productId}
                onChange={(event) => {
                  setProductId(event.target.value)
                  const product = products?.find(
                    (item) => item.id === Number(event.target.value),
                  )
                  if (product && !amount) setAmount(String(product.min_amount))
                }}
              >
                <option value="">Выберите продукт</option>
                {products?.map((product) => (
                  <option value={product.id} key={product.id}>
                    {product.bank_name} — {product.name}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Сумма кредита, ₽">
              <input
                type="number"
                min={selectedProduct ? Number(selectedProduct.min_amount) : 1}
                max={selectedProduct ? Number(selectedProduct.max_amount) : undefined}
                step="0.01"
                required
                value={amount}
                onChange={(event) => setAmount(event.target.value)}
              />
            </Field>

            <Field label="Срок, месяцев">
              <input
                type="number"
                min={selectedProduct?.min_term_months ?? 1}
                max={selectedProduct?.max_term_months ?? 360}
                required
                value={term}
                onChange={(event) => setTerm(event.target.value)}
              />
            </Field>

            <Field label="Цель кредита">
              <input
                minLength={3}
                maxLength={255}
                required
                value={purpose}
                onChange={(event) => setPurpose(event.target.value)}
                placeholder="Например, ремонт квартиры"
              />
            </Field>

            <Field label="Ежемесячный доход, ₽">
              <input
                type="number"
                min="0.01"
                step="0.01"
                required
                value={income}
                onChange={(event) => setIncome(event.target.value)}
                placeholder="Ваш доход до вычета расходов"
              />
            </Field>

            <Field label="Занятость">
              <input
                minLength={2}
                maxLength={100}
                required
                value={employment}
                onChange={(event) => setEmployment(event.target.value)}
                placeholder="Например, работаю по найму"
              />
            </Field>

            {error && <ErrorMessage>{error}</ErrorMessage>}

            <button className="primary-button form-submit" type="submit" disabled={loading}>
              {loading ? 'Сохраняем…' : 'Создать черновик заявки'}
            </button>
          </form>
        )}
      </section>
    </>
  )
}

function ApplicationPage({ user }: { user: User | null }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const [application, setApplication] = useState<Application | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [message, setMessage] = useState('')
  
useEffect(() => {
  if (!user || !id) return

  let cancelled = false

  async function fetchApplication() {
    try {
      const response = await api.get<Application>(`/applications/${id}`)
      if (!cancelled) setApplication(response.data)
    } catch (err) {
      if (!cancelled) setError(getErrorMessage(err))
    } finally {
      if (!cancelled) setLoading(false)
    }
  }

  void fetchApplication()

  return () => {
    cancelled = true
  }
}, [user, id])


  if (!user) return <Navigate to="/login" replace />
  if (loading) return <LoadingState />

  async function submitApplication() {
    if (!id) return
    setError('')
    setMessage('')
    setSubmitting(true)

    try {
      const response = await api.post<Application>(`/applications/${id}/submit`)
      setApplication(response.data)
      setMessage('Заявка отправлена на рассмотрение.')
    } catch (err) {
      setError(getErrorMessage(err))
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <PageHeading
        eyebrow={`ЗАЯВКА № ${id ?? ''}`}
        title="Информация о заявке"
        description="Подробности, расчёт и текущий статус вашей заявки."
      />

      {error && <ErrorMessage>{error}</ErrorMessage>}
      {message && <StatusMessage>{message}</StatusMessage>}

      {application && (
        <section className="content-card">
          <div className="application-detail-heading">
            <div>
              <span className="eyebrow">ТЕКУЩИЙ СТАТУС</span>
              <h2>{statusLabel(application.status)}</h2>
            </div>
            <span className={`status-pill status-${application.status}`}>
              {statusLabel(application.status)}
            </span>
          </div>

          <div className="details-list">
            <div><span>Цель кредита</span><strong>{application.purpose}</strong></div>
            <div><span>Сумма</span><strong>{formatMoney(application.amount)}</strong></div>
            <div><span>Срок</span><strong>{application.term_months} мес.</strong></div>
            <div><span>Ежемесячный доход</span><strong>{formatMoney(application.monthly_income)}</strong></div>
            <div><span>Занятость</span><strong>{application.employment}</strong></div>
            <div><span>Ежемесячный платёж</span><strong>{formatMoney(application.monthly_payment)}</strong></div>
            <div><span>Общая сумма выплат</span><strong>{formatMoney(application.total_payment)}</strong></div>
            <div><span>Переплата</span><strong>{formatMoney(application.overpayment)}</strong></div>
            <div><span>Создана</span><strong>{formatDate(application.created_at)}</strong></div>
          </div>

          {application.comment && (
            <p className="application-note"><strong>Комментарий:</strong> {application.comment}</p>
          )}
          {application.decision_comment && (
            <p className="application-note"><strong>Решение:</strong> {application.decision_comment}</p>
          )}

          {application.status === 'draft' && (
            <div className="application-actions">
              <button
                className="primary-button"
                onClick={() => void submitApplication()}
                disabled={submitting}
              >
                {submitting ? 'Отправляем…' : 'Отправить на рассмотрение'}
              </button>
            </div>
          )}
          <button className="secondary-button button-spaced" onClick={() => navigate('/applications')}>
            К моим заявкам
          </button>
        </section>
      )}
    </>
  )
}

function NotFoundPage() {
  return (
    <section className="content-card">
      <h1>Страница не найдена</h1>
      <p>Проверьте адрес или вернитесь на главную.</p>
      <NavLink to="/dashboard">На главную</NavLink>
    </section>
  )
}

export default function App() {
  const [token, setToken] = useState<string | null>(
    () => localStorage.getItem(TOKEN_KEY),
  )
  const [user, setUser] = useState<User | null>(null)
  const [checkingSession, setCheckingSession] = useState(Boolean(token))

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY)
    delete api.defaults.headers.common.Authorization
    setToken(null)
    setUser(null)
    setCheckingSession(false)
  }, [])

  const login = useCallback((accessToken: string, currentUser: User) => {
    localStorage.setItem(TOKEN_KEY, accessToken)
    api.defaults.headers.common.Authorization = `Bearer ${accessToken}`
    setToken(accessToken)
    setUser(currentUser)
    setCheckingSession(false)
  }, [])

useEffect(() => {
  if (!token) {
    delete api.defaults.headers.common.Authorization
    return
  }

  let cancelled = false

  api.defaults.headers.common.Authorization = `Bearer ${token}`

  async function checkSession() {
    try {
      const response = await api.get<User>('/auth/me')

      if (!cancelled) {
        setUser(response.data)
      }
    } catch {
      if (!cancelled) {
        logout()
      }
    } finally {
      if (!cancelled) {
        setCheckingSession(false)
      }
    }
  }

  void checkSession()

  return () => {
    cancelled = true
  }
}, [token, logout])

  if (checkingSession) {
    return <div className="session-loading">Проверяем сессию…</div>
  }

  return (
    <Layout user={user} onLogin={login} onLogout={logout}>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage user={user} />} />
        <Route path="/credits" element={<CreditsPage />} />
        <Route path="/credits/compare" element={<ComparePage />} />
        <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <LoginPage onLogin={login} />} />
        <Route path="/register" element={user ? <Navigate to="/dashboard" replace /> : <RegisterPage onLogin={login} />} />
        <Route path="/applications" element={<ApplicationsPage user={user} />} />
        <Route path="/applications/new" element={<NewApplicationPage user={user} />} />
        <Route path="/applications/:id" element={<ApplicationPage user={user} />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Layout>
  )
}
